myTheme<-theme_minimal() +
  theme(axis.text=element_blank(),
        panel.grid=element_line(color="transparent"),
        plot.title = element_text(size=48, hjust=0.5))
